#ifndef __USER_TASKS_H
#define __USER_TASKS_H

#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////////////
#include "main.h"

void	USR_Task_RunLoop(void);

////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif

#endif /* __USER_TASKS_H */
