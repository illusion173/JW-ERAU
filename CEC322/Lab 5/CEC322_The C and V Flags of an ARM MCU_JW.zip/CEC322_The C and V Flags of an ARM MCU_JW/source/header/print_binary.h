#ifndef __PRINT_BINARY_H
#define __PRINT_BINARY_H
#ifdef __cplusplus
extern "C" {
#endif
////////////////////////////////////////////////
#include <stdint.h>

////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif
#endif /* __PRINT_BINARY_H */

