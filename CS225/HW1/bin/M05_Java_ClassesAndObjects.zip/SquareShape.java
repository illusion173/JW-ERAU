//*************************************************
// Class: SquareShape (child of GenericShape)
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: In class demonstration of inheritance.
//          This class is a child class, extending GenericShape
//          Note: Assume the square is aligned with the x,y-axes.
//
// Attributes:
//
// Methods:
//
//*******************************************************
public class SquareShape extends GenericShape {
	private double sideLength;
	
	//******** Methods ************************************
	
	//******** Setters & Getters **************************
	public void setSideLength( double newSideLength) {
		sideLength = newSideLength;
	}
	
	public double getSideLength() {
		return sideLength;
	}
}