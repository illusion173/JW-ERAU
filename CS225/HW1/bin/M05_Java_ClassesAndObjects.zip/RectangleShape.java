//*************************************************
// Class: RectangleShape (child of GenericShape)
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: In class demonstration of inheritance.
//          This class is a child class, extending GenericShape.
//          Note: Assume the rectangle is aligned with the x,y-axes.
//
// Attributes:
//
// Methods:
//
//*******************************************************
public class RectangleShape extends GenericShape {
	
	
	//******** Methods ************************************
	
	//******** Setters & Getters **************************
	
}