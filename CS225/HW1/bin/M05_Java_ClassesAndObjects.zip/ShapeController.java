//*************************************************
// Class: ShapeController (uses GenericShape, CircleShape,
//                         SquareShape, RectangleShape )
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: In class inheritance demonstration.
//
// Attributes:
//
// Methods:
//
//*******************************************************
public class ShapeController {

	public static void main(String[] args) {
		CircleShape circle1 = new CircleShape();
		circle1.displayShapeInfo();
		
		circle1.setRadius(10.0);
		circle1.setXLoc(50.0);
		circle1.setYLoc(25.0);
		circle1.setObjectName("Frodo");
		circle1.displayShapeInfo();
		circle1.calculateArea();
		
		CircleShape circle2 = new CircleShape();
		circle2.setRadius(20.0);
		circle2.setXLoc(-25.0);
		circle2.setYLoc(-25.0);
		circle2.setObjectName("Biff");
		circle2.displayShapeInfo();
		
		circle1 = new CircleShape();
		circle1.displayShapeInfo();
		circle2.displayShapeInfo();
		//circle2.main(String[] nostring;);
		
	}
	
	
}