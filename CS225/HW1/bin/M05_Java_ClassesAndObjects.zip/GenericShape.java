//*************************************************
// Class: GenericShape
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: In class inheritance demonstration.
//          This class serves as the parent class for more specific shapes
//
// Attributes: 	xLoc: double
//				yLoc: double
//				objectName: String
//
// Methods: displayShapeInfo: void - prints information about the shape
//			calculateArea(): double - calculates and returns the area of the shape
//			calculatePerimiter(): double - calculates and returns the peremiter of the shape
//			calculateCenterOfMass(): double[] - calculates and returns the (x,y) coordinates of the
//												center of mass as a vector of length 2
//
//*******************************************************
public class GenericShape {
	private double xLoc, yLoc;
	private String objectName;
	
	//******** Methods **********************************
	public void displayShapeInfo() {
		System.out.println("This is a generic shape and you shouldn't be seeing this.");
	}
	
	public double calculateArea() {
		System.out.println("calculateArea called from GenericShape - please overwrite this method.");
		return -1.0;
	}
	
	public double calculatePerimiter() {
		System.out.println("calculatePerimiter called from GenericShape - please overwrite this method.");
		return -1.0;
	}
	
	public double[] calculateCenterOfMass() {
		System.out.println("calculateCenterOfMass called from GenericShape - please overwrite this method.");
		double[] centerOfMassxyCoordinates = new double[2];
		return centerOfMassxyCoordinates;
	}
	
	//******** Setters & Getters ************************
	public void setXLoc( double newXLoc ) {
		xLoc = newXLoc;
	}
	
	public double getXLoc() {
		return xLoc;
	}
	
		public void setYLoc( double newYLoc ) {
		yLoc = newYLoc;
	}
	
	public double getYLoc() {
		return yLoc;
	}
	
	public void setObjectName( String newName) {
		objectName = newName;
	}
	
	public String getObjectName() {
		return objectName;
	}
	
	
}