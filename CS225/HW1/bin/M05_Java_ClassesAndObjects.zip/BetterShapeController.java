//*************************************************
// Class: BetterShapeController
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: Alternate in class demonstration of inheritance, 
//          showing how and why to keep 'main' clean.
//
// Attributes:
//
// Methods:
//
//*******************************************************
public class BetterShapeController {
	private CircleShape obj1, obj2;
	private SquareShape obj3, obj5;
	private RectangleShape obj4;
	
	public static void main(String[] args) {
		BetterShapeController me = new BetterShapeController();
		
		me.buildCircles();
		me.buildSquares();
		me.displayAllShapeInfo();
		me.findLargerArea(me.obj1, me.obj2);
		me.findLargerArea(me.obj1, me.obj3);
		
	}
		
	//******** Methods ************************************
	public void buildCircles() {
		System.out.println("The buildCircles method in the BetterShapeController class is undefined.");
	}
	
	public void buildSquares() {
		System.out.println("The buildSquares method in the BetterShapeController class is undefined.");
	}
	
	public void displayAllShapeInfo() {
		System.out.println("The displayAllShapeInfo method in the BetterShapeController class is undefined.");
	}
	
	public void findLargerArea( GenericShape s1, GenericShape s2) {
		System.out.println("The findLargerArea method in the BetterShapeController class is undefined.");
	}
	
	
	
	//******** Setters & Getters **************************
		
		
}