//*************************************************
// Class: CircleShape (child of GenericShape)
// Author: Keith Garfield
// Date Created: Jan 30, 2019
// Date Modified: Jan 30, 2019
//
// Purpose: In class demonstration of inheritance.
//          This class is a child class, extending GenericShape
//
// Attributes:
//
// Methods:
//
//*******************************************************
public class CircleShape extends GenericShape {
	private double radius;
	
	//******** Methods ************************************
	public void displayShapeInfo() {
		double[] centerOfMassxyCoordinates = calculateCenterOfMass();
		
		System.out.println("This is CircleShape named " + getObjectName() + ".");
		System.out.println("Its (x, y) position is (" + getXLoc() + ", " + getYLoc() + ").");
		System.out.println("Its radius is " + radius + ".");
		System.out.println("Center of mass (x, y) is at (" + centerOfMassxyCoordinates[0] + ", " + centerOfMassxyCoordinates[1] + ").");
		System.out.println("    ");
	}
	
	public double calculateArea() {
		return radius * radius * Math.PI;
	}
	
	public double calculatePerimiter() {
		return 2 * radius * Math.PI;
	}
	
	public double[] calculateCenterOfMass() {
		double[] centerOfMassxyCoordinates = new double[2];
		
		centerOfMassxyCoordinates[0] = getXLoc();
		centerOfMassxyCoordinates[1] = getYLoc();

		return centerOfMassxyCoordinates;
	} 



	public static void main(String[] args) {
		System.out.println("Just showing that you can have main in multiple classes.");
		System.out.println("This is the main method in the CircleShape class.");
		System.out.println("Why do this? You can execute portions of code under development.");
	}
	
	//******** Setters & Getters **************************
	public void setRadius( double newRadius) {
		radius = newRadius;
	}
	
	public double getRadius() {
		return radius;
	}
	
}