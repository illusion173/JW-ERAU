/* 
*	Labone.java 
*	Written By: Jeremiah Webb ID 2545328 
*	CS 225 Fall 2021
*/ 

public class Labone {
	//class variables
	public static int year;



public static void main(String[] args) { 
	String firstName="Jeremiah"; String lastName="Webb"; year=2021; 
	System.out.println("Hello My Name is: "); 
	System.out.println(firstName +" " + lastName); 
	System.out.println("This is my first program of fall " + year); 

}

}



