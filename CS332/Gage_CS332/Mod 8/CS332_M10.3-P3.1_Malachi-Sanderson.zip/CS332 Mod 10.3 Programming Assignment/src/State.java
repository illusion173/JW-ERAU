import java.util.TreeMap;

/**
 * This definition of a state is dependent on the assumption that there are only ever two
 * possible inputs/actions (a and b) for which a state must account for and thus every state 
 * is simply defined by which its delta state transitions table.
 * 
 * <p>
 * I choose to represent the input and outputs for each state as a {@link #transitions tree map}, partially for cleanliness 
 * but mostly because I wanted to get some experience working with them. 
 * </p>
 * 
 * <p>
 * Each tree map is composed of just two key-value pairs...
 * <pre>
 * 	1.) (true,State_i) --> true represents inputting "a" in this given state and State_i represents which state the "a" input causes a transition to.
 * 	2.) (false,State_i) --> --> false represents inputting "b" in this given state and State_i represents which state the "b" input causes a transition to.
 * </pre>
 * </p>
 *
 * @author Malachi Gage Sanderson
 * @since 11/12/21
 *
 */
public class State 
{
	private int stateNumber;
	private TreeMap<Boolean, State> transitions = new TreeMap<>();
	
	/**
	 * 
	 * @param stateNum an integer to represent this state.
	 * @param ifA what state does it transition to if input A (AKA true).
	 * @param ifB what state does it transition to if input B (AKA false).
	 */
	public State(int stateNum)
	{
		stateNumber = stateNum;
		
	}
	
	public void setupTransitions(State ifA,State ifB) throws Exception
	{
		if(ifA == null || ifB == null)
		{
			System.out.println("ERROR ONE OF THE STATES WAS NULL");
			throw new Exception();
		}
		else
		{
			transitions.put(true, ifA);
			transitions.put(false, ifB);
		}
			
			
	}
	
	
	public State copyState()
	{
		State temp = new State(this.stateNumber);
		try 
		{
			temp.setupTransitions(this.getTransitionA(), this.getTransitionB());
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}
	
	
	
	public void printState()
	{
		System.out.println("State: q"+ getStateNumber() + "; A --> q" + getTransitionA().getStateNumber() + "; B -->  q" + getTransitionB().getStateNumber());
	}
	
	//-------------GETTERS AND SETTERS JUST IN CASE THEY ARE NEEDED------------------------
	public State getTransitionA()
	{
		return transitions.get(true);
	}
	
	public State getTransitionB()
	{
		return transitions.get(false);
	}
	public int getStateNumber()
	{
		return stateNumber;
	}

}
