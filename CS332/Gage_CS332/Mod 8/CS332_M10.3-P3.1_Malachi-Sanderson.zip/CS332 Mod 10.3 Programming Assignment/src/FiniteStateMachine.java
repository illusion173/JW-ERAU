import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * 
 */

/**
 * My code takes a .txt file that holds delta transition table information and uses that to generate 
 * a FSM for <b>ANY</b> language that uses the alphabet sigma = {a, b}. 
 * It starts the user at the start state and lets the user input values to the string and traverse the statemachine according
 * the transition rules given in the delta transformation table.
 * <p>
 * In my state machine simulation we use the alphabet including the symbols a and b and in some parts of the code
 * I treat them as boolean values as there is only two values and treating them like boolean
 * values simplifies some of the code. 
 * </p>
 * 
 * <p>
 * a --> true;
 * b --> false;
 * 
 * </p>
 * 
 * <p>
 * This works under the assumption that for a state machine to be generated, 
 * you are given the delta list as a .txt file which lists each state and the corresponding
 * state transition (further detail in {@link #generateStateMachineFromFile(File)}. An additional major
 * assumption that is made is that the first state on the {@link #deltaTable delta table file} is 
 * the start state.
 * 
 * </p>
 * 
 * @author Malachi Gage Sanderson
 * @since 11/9/21
 * 
 * 
 *  <b>Problem statement:</b> Encode a finite state machine in an object-oriented or imperative language.  One of the 
 *  following alphabets must be used: sigma = {0, 1}  or sigma = {a, b}. There is no required format for strings. 
 *  Strings may be represented as strings or arrays of integers/characters or other data structure of your choice.
 *  
 * 
 * <b>Deliverables:</b>
 *  <pre>
 *  1.) The code, and any data files used by the code.
 *  2.) A screen shot or short video demonstrating the execution of the code. The execution's input and output must be clearly presented.
 *  </pre>
 * 
 * <b> Rubric: </b>
 * <pre>
 *  1.) (5 pts) Code compiles and runs with no errors. It does not have to give correct results.
 * 
 *  2.) (5 pts) Code style and quality. Instructions are provided to the user as to how to execute and modify (if needed) the FSM.
 *  
 *  3.1) (15 pts) Code models a specific FSM, with no ability to modify the FSM. If you choose this option, you must use L = 10*1 + 01*0, or L = ab*a + ba*b 
 * (depending on the alphabet you chose). Note that you cannot achieve the full 40 points with this option!
 * 
 *  3.3) (30 pts) Code is able to model any FSM. This may be achieved using a data structure (so changing the FSM requires recompilation), or file input 
 * (so changing the FSM requires changing the contents of the data file), or user input (the code prompts the user for the FSM details)
 * </pre>
 * 
 *
 */
public class FiniteStateMachine 
{
	
	private static final String fileName = "DeltaTransitions.txt";
	private static final File deltaTable = new File(fileName);
	private static String inputtedString = "Current String: ";
	
	public static void main(String[] args) 
	{
		//readOutEveryLineInFile(deltaTable);
		
		//WARNING -- I had a memory leak issue here where it ended up closing my 23 instances of google chrome then begun working
		ArrayList<State> states = (ArrayList<State>) generateStateMachineFromFile(deltaTable).clone(); 
		State currentState = states.get(0).copyState();
		System.out.print("Current State =  ");
		currentState.printState();
		
		while(true)
		{
			System.out.println(inputtedString);
			currentState = stateTransitionInput(currentState);
		}
	}
	
	
	
	
	
	/**
	 * This is what is in the infinite while loop in main.
	 * It basically just goes through and lets the user input a value and prints 
	 * out which state they transition to from their current state.
	 * @param qi represents the current state.
	 * @return the new state they entered.
	 */
	public static State stateTransitionInput(State qi)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("From q"+ qi.getStateNumber() + " what do you want to input? Input: ");
		String in = input.next();
		if(in.equals("a") || in.equals("A") )
		{
			inputtedString += "a";
			System.out.println("Inputting A takes us to state: q"+ qi.getTransitionA().getStateNumber());
			return qi.getTransitionA();
		}
		else if(in.equals("b") || in.equals("B"))
		{
			inputtedString += "b";
			System.out.println("Inputting B takes us to state: q"+ qi.getTransitionB().getStateNumber());
			return qi.getTransitionB();
		}
		else 
		{
			System.out.println("Inputting a symbol not in the alphabet keeps us in state: q"+ qi.getTransitionB().getStateNumber());
			System.out.println("NOTE: the alphabet is composed of just the two symbols, a and b.");
			return qi;
		}
	}	
	

	/**
	 * Prints out every state and its associated transitions as given by the delta table.
	 * @param states
	 */
	public static void printStateTransitionsList(ArrayList<State> states)
	{
		for(State s : states)
		{
			s.printState();
		}
		System.out.println();
	}
	
	
	//******************************** FILE STUFF ***************************************
	
	
	/**
	 * Prints every line in a provided file.
	 * @param file
	 */
	public static void readOutEveryLineInFile(File file)
	{
		BufferedReader br = null;
		try
		{
			FileReader fr = new FileReader(file);
			System.out.println("\n\tFile Being Read: "+file.getName() + "\n\n");
			br = new BufferedReader(fr);
			String line; //used to get each individual line of the file.
			
			// while line is equal to the next line of the buffered reader is not equal to null
			// this means read the next line in the file until there are not any more line to read
			while (  (line = br.readLine()) != null ) 
			{
				System.out.println(line); // print out next line 
			}	
		}
		catch (Exception e) 
		{

			e.printStackTrace();
		}
		finally
		{
			try 
			{
				br.close();
			}
			catch(Exception e)
			{
				System.out.println("[ERROR NO BUFFERED READER TO CLOSE]");
			}
			
		}
	}
	
	
	/**
	 * This method reads the {@link #deltaTable delta table file} and uses it to set up an array list from which the simulated
	 * state machine is based. It grabs the state number and the transitions for each state to input into their own {@link State variables}
	 * NOTE: IT IS ASSUMED THAT THE FIRST STATE GIVEN ON THE .TXT FILE IS THE START STATE!
	 * <p>
	 * The delta transition tables are assumed to be provided as csv's where each line starts with an 
	 * integer that represents a state followed by a comma then another integer value which represents 
	 * the state that the initial state would transition to if "a" is the input. This value is followed 
	 * by another comma and integer which represents the state that the initial state would transition to if "b" is the input.
	 * The data is assumed to all be set up correctly in the file thus, no additional error checking/handling is done within 
	 * this program.
	 * </p>
	 * 
	 * Example of what the L = ab*a + ba*b delta file would look like... 
	 * <pre>
	 * 		0,2,4
	 * 		1,1,1
	 * 		2,3,2
	 * 		3,1,1
	 * 		4,4,5
	 * 		5,1,1
	 * </pre>
	 *  <i>**In this project's files is attached an additional JPG image that shows where these values came from for the above example language...**</i>
	 * <p>
	 * 
	 * @param file the .txt file from which it will grab all of its comma-delimited data
	 */
	public static ArrayList<State> generateStateMachineFromFile(File file)
	{
		BufferedReader br = null;
		String line; //used to get each individual line of a file.
		
		ArrayList<State> states = new ArrayList<State>(); //holds each state and all of it's associated data.
		LinkedList<ArrayList<Integer>> stateData = new LinkedList<ArrayList<Integer>>(); //double nested array list that stores the values of each state
		try
		{
			FileReader fr = new FileReader(file);
			br = new BufferedReader(fr);
			
			/*
			 * while line is equal to the next line of the buffered reader is not equal to null
			 * this means read the next line in the file until there are not any more line to read
			 */
			while (  (line = br.readLine()) != null ) 
			{
				String[] values = line.split(",");
				//trim is here just to remove any possible white space
				int stateNum = Integer.parseInt(values[0].trim());
				int stateIfA = Integer.parseInt(values[1].trim());
				int stateIfB = Integer.parseInt(values[2].trim());
				stateData.add(new ArrayList<Integer>(Arrays.asList(stateNum,stateIfA,stateIfB)) );
				//System.out.println(stateData.peekLast());
			}
			br.close();
			
			for(ArrayList<Integer> e : stateData) //first must add all states to the list of states...
			{
				states.add(new State(e.get(0))); // just grabs the first integer value from each line and makes a new state for it.
			}
			
			for(ArrayList<Integer> e : stateData) //now must set up transitions for each state...
			{
				int index = stateData.indexOf(e);
				/*
				 * so this next line is very ugly looking but it basically just translates
				 * those final two integer numbers from each line into specific states
				 * for the initial state to transition to.
				*/
				states.get(index).setupTransitions(states.get(e.get(1)), states.get(e.get(2))  );
				//states.get(index).printState();
				//System.out.println("Index "+stateData.indexOf(e) + " has: " + e + "... and points to State q" + states.get(stateData.indexOf(e)).getStateNumber()  );
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		System.out.println("The Language Copied from the Delta File is represented by...");
		printStateTransitionsList(states);
		return states;
	}
	
	
}




