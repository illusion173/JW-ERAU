# Name: Jeremiah Webb
## Class: CS315
## Submission Date: 10/10/2022
## Collaborated With: Troy Neubauer
## Description:
Program that tests 3 different data structures.
- Single linked list: Implemented with given interace. Queue: Array based Queue that implements a FIFO queue with the API implementation of page 121 of the class textbook. Cited Below.
- Stack: List based stack data structure. Additionally implemented with the API interace on page 121.
To Run: java TestClient.java

### Known Bugs: N/A

### References:
#### Websites:
	https://github.com/richss/cs315-alg-and-ds-java/blob/master/cs315-supplement/src/m1-lists/SLList.java
	https://github.com/kevin-wayne/algs4/blob/master/src/main/java/edu/princeton/cs/algs4/ResizingArrayQueue.java
    https://github.com/richss/cs315-alg-and-ds-java/blob/master/cs315-supplement/src/m1-lists/ListStack.java
#### Book:
    Algorithhms 4th Edition by Robert Sedgewick, Kevin Wayne
	
