A = 55555555555555555555552523523523525555.1305197613051976

B = -55555555555555555555252352523525555555.1305197613051976

C = 0.1

print(A)
print("Proper Formatting: %.0f" % (A))
print(B)
print("Proper Formatting: %.0f" % (B))
print(C)
print("Proper Formatting: %.0f" % (C))
